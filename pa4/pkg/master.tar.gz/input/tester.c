main(int a, int b) {
	double d;
	int i;
	printf("%d %f %d %d\n", "ya");
	for (d = 0; d < 6; d += 1) {

	}
	/*while (i == 1) {
		d += 1;
	}*/
}

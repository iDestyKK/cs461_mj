double i[8];
int a;

test(double x) {
	int y;
	float z;
	x = 2;
	if (x <= 0) {
		x = 3;
	}
	else if (x > 0) {
		x = 2;
		if (x > 10)
			if (y == 2)
				y = 2;
	}
	else
		x = 1;

	printf("%d %f\n", y, z, printf(1, 2));
	i[x];
	i[0];
	i[printf("ta da")];
}

main(int a, int b)
{
  double d;
  int i;
  printf("%d %f %d %d\n", i, d, a, b);
}

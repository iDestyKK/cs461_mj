/*
 * Functions Test 1
 *
 * Required Functions:
 *     bgnstmt, call, con, doret, exprs, fhead, fname, ftail, id, op1, op2, set
 */

add(int a, int b) {
	return a + b;
}

main() {
	int c;
	c = add(1, 2);
}

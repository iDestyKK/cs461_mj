/*
 * While Loop Test 2
 *
 * Required Functions:
 *     backpatch, bgnstmt, call, ccexpr, con, dowhile, endloopscope, fhead,
 *     fname, ftail, id, m, n, rel, set, startloopscope, string
 */

main() {
	int i, j, k;
	i = 0;
	j = 10;

	/* Classic Infinite Loop */
	while (1) {
		printf("yes\n");
	}
}

/*
 * Array Indexing Test 1
 *
 * Required Functions:
 *     bgnstmt, con, fhead, fname, ftail, id, indx, op1, set
 */

double i[8];

main() {
	int x;
	int y;
	x = 8;
	y = 2;

	i[y] = x;
}

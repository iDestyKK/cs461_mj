/*
 * While Loop Test 2
 */

main() {
	int i, j, k;
	i = 0;
	j = 10;

	/* Classic Infinite Loop */
	while (1) {
		printf("yes\n");
	}
}

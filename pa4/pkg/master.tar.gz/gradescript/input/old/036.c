/*
 * Functions Test 2
 */

add(int a, int b) {
	return a + b;
}

sub(int a, int b) {
	return a - b;
}

main() {
	int c;
	c = add(2, 2); /* Should be 5 */
	c = sub(1, 2);
}

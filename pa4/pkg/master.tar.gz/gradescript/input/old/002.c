/* 
 * Basic Test 3
 *
 * You should auto-pass this without even doing any work...
 */

double i[8];
int a;

main() {
	
}

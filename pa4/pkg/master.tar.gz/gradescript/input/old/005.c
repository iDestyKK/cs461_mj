/*
 * Variable Assignment Test 1
 */

double i[8];
int a;

main() {
	int y;

	y = 2;
}

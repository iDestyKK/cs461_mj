/*
 * For Loop Test 1
 */

main() {
	int i, j;
	for (i = 0; i < 10; i += 1) {
		printf("%d\n", i);
	}
}

/* 
 * Basic Test 1
 *
 * You should auto-pass this without even doing any work...
 */

double i[8];

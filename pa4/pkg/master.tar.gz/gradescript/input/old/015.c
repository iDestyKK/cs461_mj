/*
 * Function Calling Test 1
 */

main() {
	int x;
	x = 0;
	printf("%d\n", x);
}

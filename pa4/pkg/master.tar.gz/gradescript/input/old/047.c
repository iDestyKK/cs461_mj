/*
 * Do-While Loop Test 1
 */

main() {
	int i, j;
	i = 0;
	j = 10;

	do {
		i += 1;
	}
	while (i < j);
}

/*
 * Array Indexing Test 1
 */

double i[8];

main() {
	int x;
	int y;
	x = 8;
	y = 2;

	i[y] = x;
}

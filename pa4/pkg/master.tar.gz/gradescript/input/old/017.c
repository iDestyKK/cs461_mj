/*
 * Function Calling Test 3
 */

main() {
	int x;
	double y;
	x = 0;
	y = x + 1;
	printf("%d %f\n", x + y, y + 2);
}

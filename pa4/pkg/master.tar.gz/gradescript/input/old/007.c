/*
 * Variable Assignment Test 3
 */

double i[8];
int a;

main() {
	int y;
	int x;
	double z;

	x = 2;
	y = x;
}

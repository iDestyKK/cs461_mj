/*
 * If Statements Test w/ CCOR
 */

main() {
	int a, b, c;
	a = 2;
	b = 3;
	c = 2;

	if (a == b || b == c) {
		printf("a and b match (%d)!\n", a);
	}
}

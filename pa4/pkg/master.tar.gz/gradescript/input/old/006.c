/*
 * Variable Assignment Test 2
 */

double i[8];
int a;

main() {
	int y;
	int x;

	x = 2;
	y = x;
}

/* 
 * Basic Test 4
 *
 * You should auto-pass this without even doing any work...
 */

double i[8];
int a;

main() {
	int y;
	float z;
}

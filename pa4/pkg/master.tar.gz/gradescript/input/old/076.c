/*
 * Binary Operations Test 1 w/ NOT
 */

main() {
	int a, b;
	a = 1;
	b = 2;
	a + ~b;
}

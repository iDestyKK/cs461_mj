/*
 * Binary Operations Test 1 w/ AND
 */

main() {
	int a, b;
	a = 1;
	b = 2;
	a & b;
}

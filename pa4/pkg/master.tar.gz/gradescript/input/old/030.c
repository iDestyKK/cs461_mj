/* 
 * If Statements Test w/ CCNOT 
 */

main() {
	int a, b, c;
	a = 2;
	b = 3;
	c = 2;

	if (!a) {
		printf("a, b, and c match (%d)!\n", a);
	}
}

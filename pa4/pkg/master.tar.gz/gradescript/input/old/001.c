/* 
 * Basic Test 2
 *
 * You should auto-pass this without even doing any work...
 */

double i[8];
int a;

/*
 * Binary Operations Test 1 w/ XOR (Multiple)
 */

main() {
	int a, b;
	a = 1;
	b = 2;
	a ^ b;
	b ^ a;
	a ^ b ^ b;
}

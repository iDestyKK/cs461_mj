/*
 * Functions Test 1
 */

add(int a, int b) {
	return a + b;
}

main() {
	int c;
	c = add(1, 2);
}

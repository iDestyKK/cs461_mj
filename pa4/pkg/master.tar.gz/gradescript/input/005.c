/*
 * Variable Assignment Test 1
 *
 * Required Functions:
 *     bgnstmt, con, fhead, fname, ftail, id, set
 */

double i[8];
int a;

main() {
	int y;

	y = 2;
}

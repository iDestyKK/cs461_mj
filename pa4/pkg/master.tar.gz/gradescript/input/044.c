/*
 * While Loop Test 1
 *
 * Required Functions:
 *     backpatch, bgnstmt, con, dowhile, endloopscope, fhead, fname, ftail, id,
 *     m, n, op1, rel, set, startloopscope
 */

main() {
	int i, j;
	i = 0;
	j = 10;

	while (i < j) {
		i += 1;
	}
}

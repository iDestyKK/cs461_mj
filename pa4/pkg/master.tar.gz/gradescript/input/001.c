/* 
 * Basic Test 2
 *
 * Required Functions:
 *     
 *
 * You should auto-pass this without even doing any work...
 */

double i[8];
int a;

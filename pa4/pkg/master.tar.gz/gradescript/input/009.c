/*
 * Variable Assignment Test 5
 *
 * Required Functions:
 *     bgnstmt, con, fhead, fname, ftail, id, op1, set
 */

double i[8];
int a;

main() {
	int y;
	int x;
	double z;

	x = 2;
	y = x;
	z = y = x;
}

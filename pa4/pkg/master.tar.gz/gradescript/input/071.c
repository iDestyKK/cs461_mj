/*
 * Binary Operations Test 1 w/ OR (Multiple)
 *
 * Required Functions:
 *     bgnstmt, con, fhead, fname, ftail, id, op1, opb, set
 */

main() {
	int a, b;
	a = 1;
	b = 2;
	a | b;
	b | a;
	a | b | b;
}

/* 
 * Basic Test 5
 *
 * Required Functions:
 *     fhead, fname, ftail
 *
 * You should auto-pass this without even doing any work...
 */

double i[8];
int a;

main() {
	int y;
	float z;
	double w;
}

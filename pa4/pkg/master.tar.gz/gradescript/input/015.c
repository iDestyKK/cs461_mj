/*
 * Function Calling Test 1
 *
 * Required Functions:
 *     bgnstmt, call, con, exprs, fhead, fname, ftail, id, op1, set, string
 */

main() {
	int x;
	x = 0;
	printf("%d\n", x);
}

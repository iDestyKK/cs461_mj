/*
 * Function Calling Test 3
 *
 * Required Functions:
 *     bgnstmt, call, con, exprs, fhead, fname, ftail, id, op1, op2, set, string
 */

main() {
	int x;
	double y;
	x = 0;
	y = x + 1;
	printf("%d %f\n", x + y, y + 2);
}

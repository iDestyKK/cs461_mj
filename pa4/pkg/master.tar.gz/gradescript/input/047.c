/*
 * Do-While Loop Test 1
 *
 * Required Functions:
 *     backpatch, bgnstmt, con, dodo, endloopscope, fhead, fname, ftail, id, m,
 *     op1, rel, set, startloopscope
 */

main() {
	int i, j;
	i = 0;
	j = 10;

	do {
		i += 1;
	}
	while (i < j);
}

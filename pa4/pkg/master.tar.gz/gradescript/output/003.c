alloc i 64
alloc a 4
func main
localloc 4
localloc 8
fend

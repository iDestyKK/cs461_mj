alloc i 64
alloc a 4
func main
fend

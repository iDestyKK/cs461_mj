alloc i 64
alloc a 4
func main
localloc 4
localloc 4
bgnstmt 15
t1 := local 1
t2 := 2
t3 := t1 =i t2
bgnstmt 16
t4 := local 0
t5 := local 1
t6 := @i t5
t7 := t4 =i t6
fend

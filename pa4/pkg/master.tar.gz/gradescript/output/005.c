alloc i 64
alloc a 4
func main
localloc 4
bgnstmt 14
t1 := local 0
t2 := 2
t3 := t1 =i t2
fend

func main
localloc 4
localloc 4
bgnstmt 10
t1 := local 0
t2 := 1
t3 := t1 =i t2
bgnstmt 11
t4 := local 1
t5 := 2
t6 := t4 =i t5
bgnstmt 12
t7 := local 0
t8 := @i t7
t9 := local 1
t10 := @i t9
t11 := ~i t10
t12 := t8 +i t11
fend

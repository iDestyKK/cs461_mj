# NFA2DFA (C++ Edition)
Essentially this is "skeleton code" for the C variant of this homework. I decided that trying to write this entirely in C on my first try wasn't going to cut it so I'd give C++ a go.

Converts an E-NFA parsed from a text file (examples are somewhere in this repo I guess) to a DFA.

## Synopsis
```
./nfa2dfa < nfa_file > dfa_file
```

#!/bin/bash

tar -xJvf input.tar.xz
tar -xJvf output.tar.xz

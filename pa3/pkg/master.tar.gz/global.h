typedef enum error_n {
	ERROR_NONE,
	ERROR_OVERFLOW,
	ERROR_DIVBYZERO
} ERROR_N;

extern ERROR_N error_val;

extern int vars[26];
